Steps to Upload Firmware
########################

1. Connect the device to your laptop
2. Check the port on which the device is mapped using the hardware manager e.g. COM3, /dev/ttyUSB0 etc. depending on your Operating System
3. Open a command prompt and navigate to the firmware directory 
4. Run the command below based on your Operating System


[Windows]

python esptool.py --chip esp32 --port COM3 --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size detect 0x1000 bootloader.bin 0x10000 winx-scanner.bin 0x8000 partitions_winx-scanner.bin

[Linux]

python esptool.py --chip esp32 --port /dev/ttyUSB0 --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size detect 0x1000 bootloader.bin 0x10000 winx-scanner.bin 0x8000 partitions_winx-scanner.bin

[Mac OS]

python esptool.py --chip esp32 --port /dev/cu.SLAB_USBtoUART --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size detect 0x1000 bootloader.bin 0x10000 winx-scanner.bin 0x8000 partitions_winx-scanner.bin

5. You should now refer to the User Manual of the firmware to understand how to work with the device

