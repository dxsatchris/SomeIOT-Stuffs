#!/usr/bin/python

# Receiver utility to be used with WiNX and WiNX Portable's Sniffer firmware
# This received SLIP encoded packets from the device containing the sniffed WiFi packets
# and then writes them into a pcap file so tools such as Wireshark, Tshark and Airodump-NG can use it. 

# Store: http://www.HackerArsenal.com

# Attack-Defense Training:   http://www.PentesterAcademy.com



import sys
import time
import struct
import os
import serial
import errno
import argparse


# this is the baud rate our custom firmware uses for the sniffer module
# there should be no reason to change this 
HA_BAUD    = 921600


# Functions taken and modified from Espressif's esptool 

class ESPSniffer(object):

    def __init__(self, port):
    
        if isinstance(port, serial.Serial):
            self._port = port
        else:
            self._port = serial.serial_for_url(port)
        self._slip_reader = slip_reader(self._port)
        self._port.baudrate = HA_BAUD


    def read(self):
        return next(self._slip_reader)

    def write(self, packet):
        buf = b'\xc0' \
              + (packet.replace(b'\xdb',b'\xdb\xdd').replace(b'\xc0',b'\xdb\xdc')) \
              + b'\xc0'
        self._port.write(buf)

def slip_reader(port):
    partial_packet = None
    in_escape = False
    while True:
        waiting = port.inWaiting()
        read_bytes = port.read(1 if waiting == 0 else waiting)
        if read_bytes == b'':
            raise 
        for b in read_bytes:

            if type(b) is int:
                b = bytes([b]) 

            if partial_packet is None:  
                if b == b'\xc0':
                    partial_packet = b""

            elif in_escape:  
                in_escape = False
                if b == b'\xdc':
                    partial_packet += b'\xc0'
                elif b == b'\xdd':
                    partial_packet += b'\xdb'
                else:
                    raise 
            elif b == b'\xdb':  
                in_escape = True
            elif b == b'\xc0': 
                yield partial_packet
                partial_packet = None
            else:  
                partial_packet += b


class PcapWriter:
    def __init__(self, filename):
        self.filed = open(filename,'wb')
        self.pcap_header()

    def pcap_header(self):
        
	self.filed.write(struct.pack('I',0xa1b2c3d4))
        self.filed.write(struct.pack('H',2))
        self.filed.write(struct.pack('H',4))
        self.filed.write(struct.pack('i',0))
        self.filed.write(struct.pack('I',0))
        self.filed.write(struct.pack('I',65535))
        self.filed.write(struct.pack('I',105))

    def write_data(self, data):

	self.filed.write(struct.pack('I',int(time.time())))
        self.filed.write(struct.pack('I',0))
        self.filed.write(struct.pack('I',len(data)))
        self.filed.write(struct.pack('I',len(data)))
        self.filed.write(data)


    def close_pcap(self):
        self.filed.close()


print "*****************************************************"
print "WiNX and WiNX Portable Sniffer Firmware Helper Script\n"
print "\nWebsite: www.HackerArsenal.com"
print "*****************************************************\n"

parser = argparse.ArgumentParser(description='WiNX/WiNX Portable Sniffer Firmware Helper Utility')

parser.add_argument('-p' , action='store', dest= "serial_port_path", help='Serial Port Path e.g. /dev/ttyUSB0 (Linux), COM5 (Windows), /dev/cu.SLAB_USBtoUART (MACOS). Please ensure you have sufficient permissions to access the Serial port.') 

parser.add_argument('-f', action="store" , dest="file_name", help='Name of PCAP file to store received packets')

user_inputs = parser.parse_args()

if not (user_inputs.serial_port_path and user_inputs.file_name) :
	print "Invalid or Incomplete Argument List! exiting ..."
	sys.exit(-1)


print "[+] Opening Serial port: ",user_inputs.serial_port_path
sniffer = ESPSniffer(user_inputs.serial_port_path)

print "[+] Creating PCAP files to write packets"
writer = PcapWriter(user_inputs.file_name)

counter = 1

channel = 0

print "[+] Starting sniffer ... waiting to receive packets"
print "\n\n[INFO] If you do not see any packets after more than 10 seconds, reset the device using the 'EN' button\n\n"

while 1: 

	pkt =  sniffer.read()
		
	# sometimes the device might reset but not start the tasks automatically
	# need to reset the device
	if pkt.find('POWERON_RESET') != -1 :
		print "POWERON_RESET detected! Reset device using the 'EN' button!"
		continue 
	if pkt:

		# check our custom magic to ensure this packet was sent by our process on the device
		# as in some cases there can be garbage sent on device start 
		if pkt[0] != 'N' and pkt[1] != 'X' and pkt[2] != 'P' :
			print "Not a valid Wi-Fi packet! skipping! ", pkt
			continue

		if pkt[4] == 'C' and pkt[5] == 'C' and pkt[6] == 'N' :
			# Received a channel change notification
			print "\n***********************************************"
	        	print "Channel Change Notification! New Channel:",struct.unpack('B', pkt[3])[0]
			print "***********************************************\n"
			continue 

		if len(pkt) <= 20:
			continue 
	
		raw_pkt = pkt[4::]


		try :


			channel = struct.unpack('B', pkt[3])[0]	

			writer.write_data(raw_pkt)
			print "Packet No:",counter,"received on Channel:",channel," and written to file:",user_inputs.file_name
		except:
			print 'Erorr parsing packet (contents): ', raw_pkt

		counter += 1



